/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package windowP2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Point;
import java.util.Arrays;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

/**
 *
 * @author j2a0a
 */
public class Operacion1 extends javax.swing.JPanel {

    /**
     * Creates new form Operacion1
     */
    private JLabel[][] matriz;
    private int[][] matriz_random;

    public int[][] getMatriz_random() {
        return matriz_random;
    }

    public void setMatriz_random(int[][] matriz_random) {
        this.matriz_random = matriz_random;
    }
    
    public Operacion1() {
        initComponents();
        
        derechaBtn.setBounds(800, 10, 20, 40);
        this.add(derechaBtn);
        
    }
    public JLabel[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(JLabel[][] matriz) {
        this.matriz = matriz;
    }
    
    public void addTextPane(JLabel coordenada, int j, String contenido, int posicionY){
        int labelSize = 35; // Tamaño deseado de JLabel
        int panelWidth = this.getWidth(); // Ancho del panel
        int spacingX = 5; // Espaciado horizontal
        int spacingY = 5; // Espaciado vertical
        int n = matriz_random.length; // Tamaño de la matriz
        
        // Calcular las coordenadas para centrar el JTextPane en el panel
        int x = (panelWidth - (n * labelSize + (n - 1) * spacingX)) / 2 + (j * (labelSize + spacingX));

        // Crear el JTextPane y configurar los límites
        coordenada = new JLabel();
        coordenada.setBounds(x, posicionY, labelSize, labelSize);
        coordenada.setBorder(new LineBorder(new Color(0,102,102)));

        coordenada.setBackground(new Color(255,255,255));
        
        coordenada.setHorizontalAlignment(SwingConstants.CENTER);
        coordenada.setVerticalAlignment(SwingConstants.CENTER);

        coordenada.setText(contenido);

        this.add(coordenada); // Hacer el JTextPane no editable

        // Establecer el z-order para que esté en la parte superior
        this.setComponentZOrder(coordenada, 0);
    }
    
    public void obtenerDiagonalPrincipal(int[][] matrizRamdom, int[] diagonalPrincipal, int index) {
    // Caso base: si hemos recorrido toda la matriz, terminar la recursión
        if (index == matrizRamdom.length) {
            return;
        }

        // Obtener el elemento de la diagonal principal en la posición actual
        diagonalPrincipal[index] = matrizRamdom[index][index];

        // Llamar recursivamente para el siguiente elemento de la diagonal
        obtenerDiagonalPrincipal(matrizRamdom, diagonalPrincipal, index + 1);
    }
    
    public void dibujarDiagonalPrincipal(int[] diagonalPrincipal, int index) {
        int labelSize = 35; // Tamaño deseado de JLabel
        int panelWidth = this.getWidth(); // Ancho del panel
        int spacingX = 5; // Espaciado horizontal
        int spacingY = 5; // Espaciado vertical
        int n = matriz_random.length; // Tamaño de la matriz

        if (index < n) {
            // Calcular las coordenadas para centrar el JLabel en el panel
            int x = (panelWidth - (n * labelSize + (n - 1) * spacingX)) / 2 + ((index * (labelSize + spacingX)));

            // Crear el JLabel y configurar los límites
            JLabel label = new JLabel();
            label.setBounds(x, 60, labelSize, labelSize);
            label.setBorder(new LineBorder(new Color(0, 102, 102)));
            label.setBackground(new Color(255, 255, 255));
            label.setText(String.valueOf(diagonalPrincipal[index]));
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setVerticalAlignment(SwingConstants.CENTER);

            this.add(label);

            // Establecer el z-order para que esté en la parte superior
            this.setComponentZOrder(label, 0);

            // Llamar recursivamente al método con el siguiente índice
            dibujarDiagonalPrincipal(diagonalPrincipal, index + 1);
        }
    }
    
    public void dibujarDiagonalOrdenada(int[] diagonalPrincipal) {
        int n = diagonalPrincipal.length;
        JLabel[] diagonalPrincipalDibujada = new JLabel[n];

        // Ordenar la diagonal principal de forma recursiva
        ordenarArreglo(diagonalPrincipal, 0, n - 1);

        // Dibujar la diagonal principal de forma recursiva
        dibujarDiagonal(diagonalPrincipal, diagonalPrincipalDibujada, 0);
    }

    private void dibujarDiagonal(int[] diagonalPrincipal, JLabel[] diagonalPrincipalDibujada, int index) {
        if (index < diagonalPrincipal.length) {
            // Añadir JLabel con el elemento de la diagonal principal en la posición actual
            addTextPane(diagonalPrincipalDibujada[index], index, String.valueOf(diagonalPrincipal[index]), 105);

            // Llamar recursivamente para el siguiente elemento
            dibujarDiagonal(diagonalPrincipal, diagonalPrincipalDibujada, index + 1);
        }
    }
    
    public static void ordenarArreglo(int[] arreglo, int menor, int high) {
        if (menor < high) {
            int partitionIndex = particion(arreglo, menor, high, menor);

            ordenarArreglo(arreglo, menor, partitionIndex - 1);
            ordenarArreglo(arreglo, partitionIndex + 1, high);
        }
    }

    public static int particion(int[] arreglo, int menor, int high, int index) {
        if (index <= high) {
            if (arreglo[index] > arreglo[menor]) {
                swap(arreglo, index, menor);
            }
            particion(arreglo, menor, high, index + 1);
        }

        return menor;
    }

    public static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tituloLabel = new javax.swing.JLabel();
        tituloLabel1 = new javax.swing.JLabel();
        tituloLabel2 = new javax.swing.JLabel();
        derechaBtn = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        tituloLabel.setFont(new java.awt.Font("Dubai Light", 1, 16)); // NOI18N
        tituloLabel.setText("Diagonal Ordenada:");

        tituloLabel1.setFont(new java.awt.Font("Dubai Light", 1, 16)); // NOI18N
        tituloLabel1.setText("1_Ordenar la diagonal principal de mayor a menor");
        tituloLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tituloLabel1MouseEntered(evt);
            }
        });

        tituloLabel2.setFont(new java.awt.Font("Dubai Light", 1, 16)); // NOI18N
        tituloLabel2.setText("Diagonal Principal:");

        derechaBtn.setText("Siguiente");
        derechaBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        derechaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                derechaBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(308, Short.MAX_VALUE)
                .addComponent(tituloLabel1)
                .addGap(164, 164, 164)
                .addComponent(derechaBtn)
                .addGap(104, 104, 104))
            .addGroup(layout.createSequentialGroup()
                .addGap(148, 148, 148)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tituloLabel)
                    .addComponent(tituloLabel2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(derechaBtn)
                    .addComponent(tituloLabel1))
                .addGap(31, 31, 31)
                .addComponent(tituloLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tituloLabel)
                .addContainerGap(69, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void derechaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_derechaBtnActionPerformed
        Operacion2 panel2 = new Operacion2();
        showPanel(panel2);
        panel2.setMatriz_random(matriz_random);
        
        int[] diagonalSecundaria = panel2.obtenerDiagonalSecundaria(matriz_random);
        
        panel2.dibujarDiagonalSecundaria(diagonalSecundaria, 0);
        
        panel2.mostrarPromedio(diagonalSecundaria);
    }//GEN-LAST:event_derechaBtnActionPerformed

    private void tituloLabel1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tituloLabel1MouseEntered
        
    }//GEN-LAST:event_tituloLabel1MouseEntered

    public void showPanel(JPanel panel){
        panel.setSize(1010,350);
        panel.setLocation(0,0);
        
        this.removeAll();
        this.add(panel, BorderLayout.CENTER);
        this.revalidate();
        this.repaint();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton derechaBtn;
    private javax.swing.JLabel tituloLabel;
    private javax.swing.JLabel tituloLabel1;
    private javax.swing.JLabel tituloLabel2;
    // End of variables declaration//GEN-END:variables

    void ordenarDiagonal(JLabel[][] matriz) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
